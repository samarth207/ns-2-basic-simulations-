ns p1.tcl 
grep -c "d" p1_log.tr
awk -f pdr.awk -v src=2 -v dest=7 p1_log.tr>p1_pdr
xgraph p1_pdr 

